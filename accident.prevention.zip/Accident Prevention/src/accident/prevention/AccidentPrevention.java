
package accident.prevention;

import javax.swing.*;
import java.awt.*;

public class AccidentPrevention {

    // Constructor to initialize the main frame
    public AccidentPrevention() {
        // Create a new JFrame (main window)
        JFrame frame = new JFrame("Accident Prevention System");

        // Set the layout manager for the frame
        frame.setLayout(new BorderLayout());
        
        // Create a panel to hold the components
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3, 2, 10, 10)); // 3 rows, 2 columns with gaps

        // Add Labels and text placeholders for different warning systems
        JLabel weatherLabel = new JLabel("Weather Condition:");
        JTextField weatherAlert = new JTextField("No alerts");
        weatherAlert.setEditable(false); // Make it non-editable

        JLabel speedLabel = new JLabel("Speed Alert:");
        JTextField speedAlert = new JTextField("Normal speed");
        speedAlert.setEditable(false);

        JLabel otherAlertsLabel = new JLabel("Other Alerts:");
        JTextField otherAlerts = new JTextField("No other warnings");
        otherAlerts.setEditable(false);

        // Add components to the panel
        panel.add(weatherLabel);
        panel.add(weatherAlert);
        panel.add(speedLabel);
        panel.add(speedAlert);
        panel.add(otherAlertsLabel);
        panel.add(otherAlerts);

        // Add the panel to the frame
        frame.add(panel, BorderLayout.CENTER);

        // Set frame properties
        frame.setSize(400, 200); // Set the size of the window
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Close the application when the window is closed
        frame.setVisible(true); // Make the frame visible
    }

    // Main method to launch the application
    public static void main(String[] args) {
        // Create an instance of AccidentPrevention class to show the GUI
        new AccidentPrevention();
    }
}

